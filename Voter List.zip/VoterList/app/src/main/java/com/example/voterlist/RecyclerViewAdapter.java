package com.example.voterlist;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
public class  RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder> {

    private Context mcontext;
    List<EmployeeData> list;


    public RecyclerViewAdapter(List<EmployeeData> list, Context mcontext) {

        this.mcontext = mcontext;
        this.list = list;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listcard_layout, parent, false);
        return new RecyclerViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        // Set the data to textview and imageview.
        //EmployeeData list = courseDataArrayList.get(position);
       /* String s = list.getFirstname() + " " + list.getLastname()+"   " + "ID: " + list.getid() + "   " + "Age: "+ list.getAge();
        holder.T1.setText(s); */
        holder.T1.setText(list.get(position).getList());
//        holder.T2.setText(list.get(position).getFirstname());
//        holder.T3.setText(list.get(position).getLastname());
//        holder.T4.setText(list.get(position).getAge());

    }
    @Override
    public int getItemCount() {
        // this method returns the size of recyclerview
        return list.size();
    }
    // View Holder Class to handle Recycler View.
    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private TextView T1,T2,T3,T4;
        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            T1 = itemView.findViewById(R.id.text1);
//            T2 = itemView.findViewById(R.id.text2);
//            T3 = itemView.findViewById(R.id.text3);
//            T4 = itemView.findViewById(R.id.text4);
        }
    }
}



