package com.example.voterlist;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class DisplayData extends MainActivity {

    //   private ArrayList<RecyclerData> al;
    private List<EmployeeData> list;
    private ArrayList<EmployeeData> recyclerDataArrayList;
    private RecyclerView recyclerview;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recyclerlist);
        recyclerview = findViewById(R.id.review_list);

        getData();
        display();



    }
    private void getData() {
        list = new ArrayList<>();
        list = DatabaseClass.getDatabase(getApplicationContext()).getDao().getListData();
        recyclerDataArrayList = new ArrayList<>();
        recyclerDataArrayList.addAll(list);





       /* recyclerDataArrayList.add(new RecyclerData("First Name", DatabaseClass.getDatabase(getApplicationContext()).getDao().getFirstName(id)));
        recyclerDataArrayList.add(new RecyclerData("Last Name", DatabaseClass.getDatabase(getApplicationContext()).getDao().getLastname(id)));
        recyclerDataArrayList.add(new RecyclerData("Age", DatabaseClass.getDatabase(getApplicationContext()).getDao().getAge(id)));
        recyclerDataArrayList.add(new RecyclerData("Bloodgroup", DatabaseClass.getDatabase(getApplicationContext()).getDao().getBloodgroup(id)));

           if(Hideage.isChecked()) {
               recyclerDataArrayList.remove(2); */


    }


   /* private void getData() {
        list = new ArrayList<>();
        list = DatabaseClass.getDatabase(getApplicationContext()).getDao().getAllData();
        al=new ArrayList<>();
        al.addAll(list);


        // added data from arraylist to adapter class.
        RecyclerViewAdapter adapter=new RecyclerViewAdapter(al,this);

        // setting grid layout manager to implement grid view.
        // in this method '2' represents number of columns to be displayed in grid view.
        GridLayoutManager layoutManager=new GridLayoutManager(this,2);

        // at last set adapter to recycler view.
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setAdapter(adapter);

    }*/



    private void display() {
        /*for( int i=0; i<=recyclerDataArrayList.size(); i++)
        {
            displaylist= new ArrayList<>();
            displaylist.add(new EmployeeData(DatabaseClass.getDatabase(getApplicationContext()).getDao().getid(String.valueOf(recyclerDataArrayList.get(i))),DatabaseClass.getDatabase(getApplicationContext()).getDao().getFirstName(String.valueOf(recyclerDataArrayList.get(i))), DatabaseClass.getDatabase(getApplicationContext()).getDao().getLastname(String.valueOf(recyclerDataArrayList.get(i))),DatabaseClass.getDatabase(getApplicationContext()).getDao().getAge(String.valueOf(recyclerDataArrayList.get(i)))));*/

        // added data from arraylist to adapter class.
        RecyclerViewAdapter adapter = new RecyclerViewAdapter( recyclerDataArrayList, this);

        // setting grid layout manager to implement grid view.
        // in this method '2' represents number of columns to be displayed in grid view.
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);

        // at last set adapter to recycler view.
        recyclerview.setLayoutManager(layoutManager);
        recyclerview.setAdapter(adapter);
    } }


