package com.example.createdb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    Button save, Launchdetails;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        save=findViewById(R.id.bu1);
        Launchdetails=findViewById(R.id.bu2);

        save.setOnClickListener((view)->{ saveData();});

        Launchdetails.setOnClickListener((view)->{  startActivity(new Intent(getApplicationContext(), recycle.class));});



    }

            private void saveData() {

                {

                    RecyclerData model = new RecyclerData();
                    model.setTitle1("kkk");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                   /* model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);

                    model.setTitle1("first name");
                    model.setTitle2("saurav");
                    DatabaseClass.getDatabase(getApplicationContext()).getDao().insertAllData(model);*/

                }
            }}