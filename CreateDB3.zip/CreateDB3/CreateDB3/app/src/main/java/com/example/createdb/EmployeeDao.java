package com.example.createdb;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.ArrayList;
import java.util.List;
@Dao
public interface EmployeeDao {
    @Insert
    void insertAllData(RecyclerData model);

    //Select All Data
    @Query("select * from  Employee")
    List<RecyclerData> getAllData();

}
