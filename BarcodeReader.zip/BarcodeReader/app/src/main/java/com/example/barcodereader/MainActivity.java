package com.example.barcodereader;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.zxing.BarcodeReader;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {
    public Bitmap ImageViaAssests(String fileName) {
        AssetManager as = getAssets();
        InputStream is = null;
        try {
            is = as.open(fileName);

        } catch (IOException e) {
            e.printStackTrace();
        }
        Bitmap bitmap = BitmapFactory.decodeStream(is);

        return bitmap;
    }

//public native String display();
//    static {
//     System.loadLibrary("BarcodeReader");
//   }
    // camera logic
   // Button btOpen;

    //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ((TextView)findViewById(R.id.textview2)).setText(display());

//        camera logic
//        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(MainActivity.this, new String[]{
//                    Manifest.permission.CAMERA
//            }, 100);
//        }
//        btOpen.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                startActivityForResult(intent, 100);
//            }
//
//        });

       BarcodeReader s =new BarcodeReader();
        TextView t =findViewById(R.id.textview2);
        t.setText(s.show());
      try {
            //camera logic

//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        if (requestCode == 100) {
//            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
//            super.onActivityResult(requestCode, resultCode, data);
//            ImageView iv = findViewById(R.id.image1);

            //camera logic
            Bitmap bitmap = ImageViaAssests("barcode.png");
            Log.d("bitmap", "bit map value: " + bitmap);
           ImageView iv = findViewById(R.id.image1);
            iv.setImageBitmap(bitmap);
            BarcodeReader b = new BarcodeReader();
            BarcodeReader.Result rs = b.read(bitmap, bitmap.getWidth(), bitmap.getHeight());
            TextView st = findViewById(R.id.text1);
            st.setText(rs.getText());
       } catch (Exception e) {
            Log.e("IO ERROR", "Failed" + e.toString());



    }

}}

