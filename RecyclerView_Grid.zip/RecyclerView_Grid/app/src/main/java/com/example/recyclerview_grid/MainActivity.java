package com.example.recyclerview_grid;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<RecyclerData> recyclerDataArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.review);

        // created new array list..
        recyclerDataArrayList=new ArrayList<>();

        // added data to array list
        recyclerDataArrayList.add(new RecyclerData("first name","Saurav"));
        recyclerDataArrayList.add(new RecyclerData("last name","Joshi"));
        recyclerDataArrayList.add(new RecyclerData("first name","Saurav"));
        recyclerDataArrayList.add(new RecyclerData("last name","Joshi"));
        recyclerDataArrayList.add(new RecyclerData("extension","6876"));
        recyclerDataArrayList.add(new RecyclerData("first name","Saurav"));
        recyclerDataArrayList.add(new RecyclerData("last name","Joshi"));
        recyclerDataArrayList.add(new RecyclerData("Python","dfsd"));
        recyclerDataArrayList.add(new RecyclerData("Node Js","fsfsf"));
        recyclerDataArrayList.add(new RecyclerData("extension","6876"));
        recyclerDataArrayList.add(new RecyclerData("first name","Saurav"));
        recyclerDataArrayList.add(new RecyclerData("last name","Joshi"));
        recyclerDataArrayList.add(new RecyclerData("Python","dfsd"));
        recyclerDataArrayList.add(new RecyclerData("Node Js","fsfsf"));
        recyclerDataArrayList.add(new RecyclerData("last name","Joshi"));
        recyclerDataArrayList.add(new RecyclerData("Python","dfsd"));
        recyclerDataArrayList.add(new RecyclerData("Node Js","fsfsf"));
        recyclerDataArrayList.add(new RecyclerData("Node Js","fsfsf"));
        recyclerDataArrayList.add(new RecyclerData("last name","Joshi"));
        recyclerDataArrayList.add(new RecyclerData("Python","dfsd"));
        recyclerDataArrayList.add(new RecyclerData("Node Js","fsfsf"));
        recyclerDataArrayList.add(new RecyclerData("last name","Joshi"));
        recyclerDataArrayList.add(new RecyclerData("Python","dfsd"));
        recyclerDataArrayList.add(new RecyclerData("Node Js","fsfsf"));
        recyclerDataArrayList.add(new RecyclerData("last name","Joshi"));
        recyclerDataArrayList.add(new RecyclerData("Python","dfsd"));
        recyclerDataArrayList.add(new RecyclerData("Node Js","fsfsf"));
        recyclerDataArrayList.add(new RecyclerData("Node Js","fsfsf"));
        recyclerDataArrayList.add(new RecyclerData("last name","Joshi"));
        recyclerDataArrayList.add(new RecyclerData("Python","dfsd"));
        recyclerDataArrayList.add(new RecyclerData("Node Js","fsfsf"));




        // added data from arraylist to adapter class.
        RecyclerViewAdapter adapter=new RecyclerViewAdapter(recyclerDataArrayList,this);

        // setting grid layout manager to implement grid view.
        // in this method '2' represents number of columns to be displayed in grid view.
        GridLayoutManager layoutManager=new GridLayoutManager(this,3);

        // at last set adapter to recycler view.
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
    }
}
